#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")" || exit 1
INSTALLER_APP="$PWD/Lekh Keyboard Test Installer.app"
UNINSTALLER_APP="$PWD/Lekh Keyboard Uninstaller.app"
INSTALLER_BIN="$INSTALLER_APP/Contents/MacOS/install-lekh-keyboard"

echo "Lekh Keyboard terminal installer"
echo "This unsigned QA build cannot pass Finder/Gatekeeper without Developer ID notarization."
echo "This script removes the download quarantine from this extracted folder, verifies the packaged app signature, then runs the same installer."
echo

if [[ ! -x "$INSTALLER_BIN" ]]; then
  echo "Missing installer executable: $INSTALLER_BIN" >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

/usr/bin/xattr -dr com.apple.quarantine "$INSTALLER_APP" "$UNINSTALLER_APP" "$PWD" 2>/dev/null || true

if ! /usr/bin/codesign --verify --deep --strict "$INSTALLER_APP" >/dev/null 2>&1; then
  echo "The installer app failed local code-signature verification." >&2
  echo "Delete this copy and download the release zip again." >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

set +e
"$INSTALLER_BIN"
status=$?
set -e
echo
if [[ "$status" -eq 0 ]]; then
  echo "Install finished. Use the macOS input menu to select Lekh Keyboard."
else
  echo "Install failed with status $status. See ~/Library/Logs/LekhKeyboard/install.log."
fi
read -r -p "Press Return to close this window..."
exit "$status"
