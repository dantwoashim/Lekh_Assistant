#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")" || exit 1

if ! command -v minisign >/dev/null 2>&1; then
  echo "minisign is required to verify RELEASE-MANIFEST.json." >&2
  echo "Install it with: brew install minisign" >&2
  read -r -p "Press Return to close this window..."
  exit 127
fi

echo "Verifying SHA256SUMS.txt..."
/usr/bin/shasum -a 256 -c SHA256SUMS.txt

echo
echo "Verifying signed release manifest..."
minisign -Vm RELEASE-MANIFEST.json -x RELEASE-MANIFEST.json.minisig -P "$(tail -n 1 lekh-release-manifest-minisign.pub)"

echo
echo "Lekh release verification passed."
read -r -p "Press Return to close this window..."
