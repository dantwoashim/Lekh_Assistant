Lekh Keyboard Test Installer

Install:
1. Open Lekh Keyboard Test Installer.app.
2. After it finishes, use the macOS input menu in the menu bar to choose Lekh Keyboard.

Uninstall:
Open Lekh Keyboard Uninstaller.app.

Logs:
~/Library/Logs/LekhKeyboard/install.log
~/Library/Logs/LekhKeyboard/uninstall.log

This test build is local-first and does not send typing data to a server.
Production distribution still requires Developer ID signing and notarization if this zip is built without LEKH_MAC_DEVELOPER_ID.
