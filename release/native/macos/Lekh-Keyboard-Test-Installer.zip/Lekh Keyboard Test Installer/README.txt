Lekh Keyboard Test Installer

Version: 1.0.0 build 278
Signature: ad-hoc unless this package was built with LEKH_MAC_DEVELOPER_ID.

Install:
1. Extract the downloaded ZIP.
2. Control-click or right-click Lekh Keyboard Test Installer.app, choose Open, then click Open again.
3. If macOS still blocks it, open System Settings > Privacy & Security and choose Open Anyway for Lekh Keyboard Test Installer.
4. Last resort only: open Terminal, type xattr -dr com.apple.quarantine followed by one space, drag Lekh Keyboard Test Installer.app into Terminal, and press Return. Then repeat step 2. This is one command and changes only the installer app.
5. After it finishes, use the macOS input menu in the menu bar to choose Lekh Keyboard.
6. If Lekh Keyboard does not appear immediately, log out and back in, then open Keyboard Settings > Text Input > Edit and add it under Nepali.
7. Installer rollback backups are compressed under ~/Library/Application Support/Lekh Keyboard/InstallBackups.noindex and rotated to the newest 3 copies so macOS cannot rediscover them as duplicate input methods.

Uninstall:
Open Lekh Keyboard Uninstaller.app. If Finder blocks it, use Uninstall Lekh Keyboard from Terminal.command. It asks for confirmation, restores the previous keyboard when possible, deletes packs, models, backups, caches, and logs, and can optionally delete local learned words.

Logs:
~/Library/Logs/LekhKeyboard/install.log
Uninstall logs are deleted at the end of uninstall for privacy.

This test build is local-first and does not send typing data to a server.
Production distribution still requires Developer ID signing and notarization if this zip is built without LEKH_MAC_DEVELOPER_ID.
Release manifest:
Optional technical verification: run Verify Lekh Release.command through Terminal before installing. It pins the expected Minisign key, authenticates RELEASE-MANIFEST.json first, then verifies the exact closed-world file set and every file digest.

नेपाली:
१. Download गरिएको ZIP extract गर्नुहोस्।
२. Lekh Keyboard Test Installer.app मा Control-click वा right-click गरेर Open छान्नुहोस्, अनि फेरि Open थिच्नुहोस्।
३. अझै block भए System Settings > Privacy & Security मा Open Anyway छान्नुहोस्। अन्तिम विकल्पका रूपमा README मा भएको एक-line xattr command प्रयोग गर्नुहोस्।
४. स्थापना भएपछि menu bar को input menu बाट Lekh Keyboard छान्नुहोस्।
५. तुरुन्त नदेखिए log out गरेर फेरि log in गर्नुहोस्, अनि Keyboard Settings > Text Input > Edit > Nepali बाट थप्नुहोस्।
६. Uninstaller ले confirmation माग्छ र local learned words, packs, models, backups, caches, logs हटाउँछ।
