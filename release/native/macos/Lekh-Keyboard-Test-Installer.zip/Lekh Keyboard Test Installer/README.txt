Lekh Keyboard Test Installer

Version: 0.1.0 build 5
Signature: ad-hoc unless this package was built with LEKH_MAC_DEVELOPER_ID.

Install:
1. Open Lekh Keyboard Test Installer.app.
2. If macOS blocks the app because it is an unsigned test build, open System Settings > Privacy & Security and choose Open Anyway for Lekh Keyboard Test Installer.
3. After it finishes, use the macOS input menu in the menu bar to choose Lekh Keyboard.
4. If Lekh Keyboard does not appear immediately, log out and back in, then open Keyboard Settings > Text Input > Edit and add it under Nepali.
5. Installer rollback backups are stored under ~/Library/Application Support/Lekh Keyboard/InstallBackups and rotated to the newest 3 copies.

Uninstall:
Open Lekh Keyboard Uninstaller.app. It asks for confirmation, restores the previous keyboard when possible, deletes packs, models, backups, caches, and logs, and can optionally delete local learned words.

Logs:
~/Library/Logs/LekhKeyboard/install.log
Uninstall logs are deleted at the end of uninstall for privacy.

This test build is local-first and does not send typing data to a server.
Production distribution still requires Developer ID signing and notarization if this zip is built without LEKH_MAC_DEVELOPER_ID.
Release manifest:
RELEASE-MANIFEST.json is signed by RELEASE-MANIFEST.json.minisig. Verify with:
minisign -Vm RELEASE-MANIFEST.json -P $(tail -n 1 public/security/lekh-release-manifest-minisign.pub)

नेपाली:
१. Lekh Keyboard Test Installer.app खोल्नुहोस्।
२. macOS ले unsigned test build भनेर block गरेमा System Settings > Privacy & Security मा Open Anyway छान्नुहोस्।
३. स्थापना भएपछि menu bar को input menu बाट Lekh Keyboard छान्नुहोस्।
४. तुरुन्त नदेखिए log out गरेर फेरि log in गर्नुहोस्, अनि Keyboard Settings > Text Input > Edit > Nepali बाट थप्नुहोस्।
५. Uninstaller ले confirmation माग्छ र local learned words, packs, models, backups, caches, logs हटाउँछ।
