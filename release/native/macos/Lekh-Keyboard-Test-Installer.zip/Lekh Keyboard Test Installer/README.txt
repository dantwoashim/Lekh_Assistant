Lekh Keyboard Test Installer

Version: 0.1.0 build 4
Signature: ad-hoc unless this package was built with LEKH_MAC_DEVELOPER_ID.

Install:
1. Open Lekh Keyboard Test Installer.app.
2. If macOS blocks the app because it is an unsigned test build, open System Settings > Privacy & Security and choose Open Anyway for Lekh Keyboard Test Installer.
3. After it finishes, use the macOS input menu in the menu bar to choose Lekh Keyboard.
4. If Lekh Keyboard does not appear immediately, log out and back in, then open Keyboard Settings > Text Input > Edit and add it under Nepali.

Uninstall:
Open Lekh Keyboard Uninstaller.app. It asks for confirmation, restores the previous keyboard when possible, and deletes local learned words, packs, models, backups, caches, and logs.

Logs:
~/Library/Logs/LekhKeyboard/install.log
Uninstall logs are deleted at the end of uninstall for privacy.

This test build is local-first and does not send typing data to a server.
Production distribution still requires Developer ID signing and notarization if this zip is built without LEKH_MAC_DEVELOPER_ID.
