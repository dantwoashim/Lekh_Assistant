#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")" || exit 1
UNINSTALLER_APP="$PWD/Lekh Keyboard Uninstaller.app"
UNINSTALLER_BIN="$UNINSTALLER_APP/Contents/MacOS/uninstall-lekh-keyboard"

echo "Lekh Keyboard terminal uninstaller"
echo "This script removes only the known Finder metadata that blocks code-signature verification, verifies the uninstaller, then runs it."
echo

if [[ ! -x "$UNINSTALLER_BIN" ]]; then
  echo "Missing uninstaller executable: $UNINSTALLER_BIN" >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

/usr/bin/dot_clean -m "$UNINSTALLER_APP" >/dev/null 2>&1 || true
for attribute in com.apple.quarantine com.apple.FinderInfo com.apple.ResourceFork 'com.apple.fileprovider.fpfs#P' com.apple.provenance; do
  /usr/bin/xattr -r -d "$attribute" "$UNINSTALLER_APP" 2>/dev/null || true
done

if ! /usr/bin/codesign --verify --deep --strict "$UNINSTALLER_APP" >/dev/null 2>&1; then
  echo "The uninstaller app failed local code-signature verification." >&2
  echo "Delete this copy and download the release zip again." >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

set +e
"$UNINSTALLER_BIN"
status=$?
set -e
echo
if [[ "$status" -eq 0 ]]; then
  echo "Uninstall finished."
else
  echo "Uninstall failed with status $status."
fi
read -r -p "Press Return to close this window..."
exit "$status"
