#!/usr/bin/env bash
set -uo pipefail

cd "$(dirname "$0")" || exit 1
UNINSTALLER_APP="$PWD/Lekh Keyboard Uninstaller.app"
UNINSTALLER_BIN="$UNINSTALLER_APP/Contents/MacOS/uninstall-lekh-keyboard"

echo "Lekh Keyboard terminal uninstaller"
echo "This script removes the download quarantine from the uninstaller, verifies it, then runs it."
echo

if [[ ! -x "$UNINSTALLER_BIN" ]]; then
  echo "Missing uninstaller executable: $UNINSTALLER_BIN" >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

/usr/bin/xattr -dr com.apple.quarantine "$UNINSTALLER_APP" "$PWD" 2>/dev/null || true

if ! /usr/bin/codesign --verify --deep --strict "$UNINSTALLER_APP" >/dev/null 2>&1; then
  echo "The uninstaller app failed local code-signature verification." >&2
  echo "Delete this copy and download the release zip again." >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

"$UNINSTALLER_BIN"
status=$?
echo
if [[ "$status" -eq 0 ]]; then
  echo "Uninstall finished."
else
  echo "Uninstall failed with status $status."
fi
read -r -p "Press Return to close this window..."
exit "$status"
