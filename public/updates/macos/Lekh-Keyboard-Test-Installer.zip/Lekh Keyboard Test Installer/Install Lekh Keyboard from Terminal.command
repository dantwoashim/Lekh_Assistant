#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")" || exit 1
SOURCE_INSTALLER_APP="$PWD/Lekh Keyboard Test Installer.app"
SOURCE_INSTALLER_BIN="$SOURCE_INSTALLER_APP/Contents/MacOS/install-lekh-keyboard"
LOCAL_TMP_ROOT="${TMPDIR:-/tmp}"
LOCAL_TMP_ROOT="${LOCAL_TMP_ROOT%/}"
STAGING_DIR=""

cleanup_staging() {
  if [[ -n "$STAGING_DIR" && "$STAGING_DIR" == "$LOCAL_TMP_ROOT"/lekh-keyboard-installer.* ]]; then
    /bin/rm -rf -- "$STAGING_DIR"
  fi
}
trap cleanup_staging EXIT
trap 'exit 130' INT TERM HUP

echo "Lekh Keyboard terminal installer"
echo "This unsigned QA build cannot pass Finder/Gatekeeper without Developer ID notarization."
echo "This script removes only the known Finder metadata that blocks code-signature verification, verifies the packaged app signature, then runs the same installer."
echo

if [[ ! -x "$SOURCE_INSTALLER_BIN" ]]; then
  echo "Missing installer executable: $SOURCE_INSTALLER_BIN" >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

umask 077
STAGING_DIR="$(/usr/bin/mktemp -d "$LOCAL_TMP_ROOT/lekh-keyboard-installer.XXXXXX")" || {
  echo "Could not create a private local installer staging directory." >&2
  read -r -p "Press Return to close this window..."
  exit 1
}
INSTALLER_APP="$STAGING_DIR/Lekh Keyboard Test Installer.app"
INSTALLER_BIN="$INSTALLER_APP/Contents/MacOS/install-lekh-keyboard"
/usr/bin/ditto --norsrc --noextattr --noacl "$SOURCE_INSTALLER_APP" "$INSTALLER_APP" || {
  echo "Could not stage the installer outside Finder/File Provider storage." >&2
  read -r -p "Press Return to close this window..."
  exit 1
}
/usr/bin/dot_clean -m "$INSTALLER_APP" >/dev/null 2>&1 || true
for attribute in com.apple.quarantine com.apple.FinderInfo com.apple.ResourceFork 'com.apple.fileprovider.fpfs#P' com.apple.provenance; do
  /usr/bin/xattr -r -d "$attribute" "$INSTALLER_APP" 2>/dev/null || true
done

if ! verify_output="$(/usr/bin/codesign --verify --deep --strict --verbose=4 "$INSTALLER_APP" 2>&1)"; then
  echo "The metadata-free staged installer failed code-signature verification." >&2
  printf '%s
' "$verify_output" >&2
  echo "The signed app contents differ from the release archive; use a fresh package." >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

set +e
"$INSTALLER_BIN"
status=$?
set -e
echo
if [[ "$status" -eq 0 ]]; then
  echo "Install finished. Use the macOS input menu to select Lekh Keyboard."
else
  echo "Install failed with status $status. See ~/Library/Logs/LekhKeyboard/install.log."
fi
read -r -p "Press Return to close this window..."
exit "$status"
