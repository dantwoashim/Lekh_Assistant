#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")" || exit 1
SOURCE_RELEASE_DIR="$PWD"
LOCAL_TMP_ROOT="${TMPDIR:-/tmp}"
LOCAL_TMP_ROOT="${LOCAL_TMP_ROOT%/}"
STAGING_DIR=""
STAGED_RELEASE_DIR=""

cleanup_staging() {
  if [[ -n "$STAGING_DIR" && "$STAGING_DIR" == "$LOCAL_TMP_ROOT"/lekh-keyboard-uninstaller.* ]]; then
    /bin/rm -rf -- "$STAGING_DIR"
  fi
}
trap cleanup_staging EXIT
trap 'exit 130' INT TERM HUP

echo "Lekh Keyboard terminal uninstaller"
echo "This script creates a private snapshot, authenticates that exact complete release, verifies the packaged app's code signature, then runs it."
echo

umask 077
STAGING_DIR="$(/usr/bin/mktemp -d "$LOCAL_TMP_ROOT/lekh-keyboard-uninstaller.XXXXXX")" || {
  echo "Could not create a private local uninstaller staging directory." >&2
  read -r -p "Press Return to close this window..."
  exit 1
}
STAGED_RELEASE_DIR="$STAGING_DIR/Lekh Keyboard Test Installer"
/usr/bin/ditto --norsrc --noextattr --noacl "$SOURCE_RELEASE_DIR" "$STAGED_RELEASE_DIR" || {
  echo "Could not create a metadata-clean snapshot outside Finder/File Provider storage." >&2
  read -r -p "Press Return to close this window..."
  exit 1
}

cd "$STAGED_RELEASE_DIR" || exit 1
SOURCE_UNINSTALLER_APP="$PWD/Lekh Keyboard Uninstaller.app"
SOURCE_UNINSTALLER_BIN="$SOURCE_UNINSTALLER_APP/Contents/MacOS/uninstall-lekh-keyboard"
RELEASE_VERIFIER="$PWD/Verify Lekh Release.command"

if [[ ! -x "$RELEASE_VERIFIER" ]]; then
  echo "Missing release verifier in the private snapshot: $RELEASE_VERIFIER" >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi
LEKH_RELEASE_VERIFY_STAGED=1 LEKH_RELEASE_VERIFY_NONINTERACTIVE=1 "$RELEASE_VERIFIER" || {
  echo "Private release snapshot authentication failed; uninstall was not started." >&2
  read -r -p "Press Return to close this window..."
  exit 1
}

if [[ ! -x "$SOURCE_UNINSTALLER_BIN" ]]; then
  echo "Missing uninstaller executable: $SOURCE_UNINSTALLER_BIN" >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

UNINSTALLER_APP="$SOURCE_UNINSTALLER_APP"
UNINSTALLER_BIN="$UNINSTALLER_APP/Contents/MacOS/uninstall-lekh-keyboard"
if ! verify_output="$(/usr/bin/codesign --verify --deep --strict --verbose=4 "$UNINSTALLER_APP" 2>&1)"; then
  echo "The authenticated snapshot's uninstaller failed code-signature verification." >&2
  printf '%s
' "$verify_output" >&2
  echo "The signed app contents differ from the release archive; use a fresh package." >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

set +e
"$UNINSTALLER_BIN"
status=$?
set -e
echo
if [[ "$status" -eq 0 ]]; then
  echo "Uninstall finished."
else
  echo "Uninstall failed with status $status."
fi
read -r -p "Press Return to close this window..."
exit "$status"
