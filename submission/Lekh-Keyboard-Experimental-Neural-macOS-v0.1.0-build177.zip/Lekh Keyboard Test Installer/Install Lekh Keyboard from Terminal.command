#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")" || exit 1
SOURCE_RELEASE_DIR="$PWD"
LOCAL_TMP_ROOT="${TMPDIR:-/tmp}"
LOCAL_TMP_ROOT="${LOCAL_TMP_ROOT%/}"
STAGING_DIR=""
STAGED_RELEASE_DIR=""

cleanup_staging() {
  if [[ -n "$STAGING_DIR" && "$STAGING_DIR" == "$LOCAL_TMP_ROOT"/lekh-keyboard-installer.* ]]; then
    /bin/rm -rf -- "$STAGING_DIR"
  fi
}
trap cleanup_staging EXIT
trap 'exit 130' INT TERM HUP

echo "Lekh Keyboard terminal installer"
echo "This unsigned QA build cannot pass Finder/Gatekeeper without Developer ID notarization."
echo "This script creates a private snapshot, authenticates that exact complete release, verifies the packaged app's code signature, then runs the same installer."
echo

umask 077
STAGING_DIR="$(/usr/bin/mktemp -d "$LOCAL_TMP_ROOT/lekh-keyboard-installer.XXXXXX")" || {
  echo "Could not create a private local installer staging directory." >&2
  read -r -p "Press Return to close this window..."
  exit 1
}
STAGED_RELEASE_DIR="$STAGING_DIR/Lekh Keyboard Test Installer"
/usr/bin/ditto --norsrc --noextattr --noacl "$SOURCE_RELEASE_DIR" "$STAGED_RELEASE_DIR" || {
  echo "Could not create a metadata-clean snapshot outside Finder/File Provider storage." >&2
  read -r -p "Press Return to close this window..."
  exit 1
}

cd "$STAGED_RELEASE_DIR" || exit 1
SOURCE_INSTALLER_APP="$PWD/Lekh Keyboard Test Installer.app"
SOURCE_INSTALLER_BIN="$SOURCE_INSTALLER_APP/Contents/MacOS/install-lekh-keyboard"
RELEASE_VERIFIER="$PWD/Verify Lekh Release.command"

if [[ ! -x "$RELEASE_VERIFIER" ]]; then
  echo "Missing release verifier in the private snapshot: $RELEASE_VERIFIER" >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi
LEKH_RELEASE_VERIFY_STAGED=1 LEKH_RELEASE_VERIFY_NONINTERACTIVE=1 "$RELEASE_VERIFIER" || {
  echo "Private release snapshot authentication failed; installation was not started." >&2
  read -r -p "Press Return to close this window..."
  exit 1
}

if [[ ! -x "$SOURCE_INSTALLER_BIN" ]]; then
  echo "Missing installer executable: $SOURCE_INSTALLER_BIN" >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

INSTALLER_APP="$SOURCE_INSTALLER_APP"
INSTALLER_BIN="$INSTALLER_APP/Contents/MacOS/install-lekh-keyboard"
if ! verify_output="$(/usr/bin/codesign --verify --deep --strict --verbose=4 "$INSTALLER_APP" 2>&1)"; then
  echo "The authenticated snapshot's installer failed code-signature verification." >&2
  printf '%s
' "$verify_output" >&2
  echo "The signed app contents differ from the release archive; use a fresh package." >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

set +e
"$INSTALLER_BIN"
status=$?
set -e
echo
if [[ "$status" -eq 0 ]]; then
  echo "Install finished. Use the macOS input menu to select Lekh Keyboard."
else
  echo "Install failed with status $status. See ~/Library/Logs/LekhKeyboard/install.log."
fi
read -r -p "Press Return to close this window..."
exit "$status"
