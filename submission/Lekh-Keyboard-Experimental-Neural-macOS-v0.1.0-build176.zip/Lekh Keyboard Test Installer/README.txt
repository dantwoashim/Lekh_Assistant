Lekh Keyboard Test Installer

Version: 0.1.0 build 176
Signature: ad-hoc unless this package was built with LEKH_MAC_DEVELOPER_ID.

Install:
1. Install minisign with: brew install minisign
2. Run Verify Lekh Release.command. Do not install if it does not report that release verification passed.
3. Open Lekh Keyboard Test Installer.app.
4. If macOS blocks the app because it is an unnotarized test build, open System Settings > Privacy & Security and choose Open Anyway for Lekh Keyboard Test Installer.
   Do not recursively remove quarantine attributes from the download folder.
5. If macOS only shows Move to Trash or Done and no Open Anyway option appears, open Install Lekh Keyboard from Terminal.command instead; it repeats full release verification before installation.
6. After it finishes, use the macOS input menu in the menu bar to choose Lekh Keyboard.
7. If Lekh Keyboard does not appear immediately, log out and back in, then open Keyboard Settings > Text Input > Edit and add it under Nepali.
8. Installer rollback backups are compressed under ~/Library/Application Support/Lekh Keyboard/InstallBackups.noindex and rotated to the newest 3 copies so macOS cannot rediscover them as duplicate input methods.

Uninstall:
Open Lekh Keyboard Uninstaller.app. If Finder blocks it, use Uninstall Lekh Keyboard from Terminal.command. It asks for confirmation, restores the previous keyboard when possible, deletes packs, models, backups, caches, and logs, and can optionally delete local learned words.

Logs:
~/Library/Logs/LekhKeyboard/install.log
Uninstall logs are deleted at the end of uninstall for privacy.

This test build is local-first and does not send typing data to a server.
Production distribution still requires Developer ID signing and notarization if this zip is built without LEKH_MAC_DEVELOPER_ID.
Release manifest:
Verify Lekh Release.command pins the expected Minisign key, authenticates RELEASE-MANIFEST.json first, then verifies the exact closed-world file set and every file digest.

नेपाली:
१. पहिले minisign install गरेर Verify Lekh Release.command चलाउनुहोस्। verification pass नभए install नगर्नुहोस्।
२. Lekh Keyboard Test Installer.app खोल्नुहोस्।
३. macOS ले unnotarized test build भनेर block गरेमा System Settings > Privacy & Security मा Open Anyway छान्नुहोस्।
४. स्थापना भएपछि menu bar को input menu बाट Lekh Keyboard छान्नुहोस्।
५. तुरुन्त नदेखिए log out गरेर फेरि log in गर्नुहोस्, अनि Keyboard Settings > Text Input > Edit > Nepali बाट थप्नुहोस्।
६. Uninstaller ले confirmation माग्छ र local learned words, packs, models, backups, caches, logs हटाउँछ।
