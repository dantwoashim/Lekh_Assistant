#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")" || exit 1
SOURCE_UNINSTALLER_APP="$PWD/Lekh Keyboard Uninstaller.app"
SOURCE_UNINSTALLER_BIN="$SOURCE_UNINSTALLER_APP/Contents/MacOS/uninstall-lekh-keyboard"
RELEASE_VERIFIER="$PWD/Verify Lekh Release.command"
LOCAL_TMP_ROOT="${TMPDIR:-/tmp}"
LOCAL_TMP_ROOT="${LOCAL_TMP_ROOT%/}"
STAGING_DIR=""

cleanup_staging() {
  if [[ -n "$STAGING_DIR" && "$STAGING_DIR" == "$LOCAL_TMP_ROOT"/lekh-keyboard-uninstaller.* ]]; then
    /bin/rm -rf -- "$STAGING_DIR"
  fi
}
trap cleanup_staging EXIT
trap 'exit 130' INT TERM HUP

echo "Lekh Keyboard terminal uninstaller"
echo "This script authenticates the complete release, stages the packaged app, verifies its code signature, then runs it."
echo

if [[ ! -x "$RELEASE_VERIFIER" ]]; then
  echo "Missing release verifier: $RELEASE_VERIFIER" >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi
LEKH_RELEASE_VERIFY_NONINTERACTIVE=1 "$RELEASE_VERIFIER" || {
  echo "Release authentication failed; uninstall was not started." >&2
  read -r -p "Press Return to close this window..."
  exit 1
}

if [[ ! -x "$SOURCE_UNINSTALLER_BIN" ]]; then
  echo "Missing uninstaller executable: $SOURCE_UNINSTALLER_BIN" >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

umask 077
STAGING_DIR="$(/usr/bin/mktemp -d "$LOCAL_TMP_ROOT/lekh-keyboard-uninstaller.XXXXXX")" || {
  echo "Could not create a private local uninstaller staging directory." >&2
  read -r -p "Press Return to close this window..."
  exit 1
}
UNINSTALLER_APP="$STAGING_DIR/Lekh Keyboard Uninstaller.app"
UNINSTALLER_BIN="$UNINSTALLER_APP/Contents/MacOS/uninstall-lekh-keyboard"
/usr/bin/ditto --norsrc --noextattr --noacl "$SOURCE_UNINSTALLER_APP" "$UNINSTALLER_APP" || {
  echo "Could not stage the uninstaller outside Finder/File Provider storage." >&2
  read -r -p "Press Return to close this window..."
  exit 1
}
if ! verify_output="$(/usr/bin/codesign --verify --deep --strict --verbose=4 "$UNINSTALLER_APP" 2>&1)"; then
  echo "The metadata-free staged uninstaller failed code-signature verification." >&2
  printf '%s
' "$verify_output" >&2
  echo "The signed app contents differ from the release archive; use a fresh package." >&2
  read -r -p "Press Return to close this window..."
  exit 1
fi

set +e
"$UNINSTALLER_BIN"
status=$?
set -e
echo
if [[ "$status" -eq 0 ]]; then
  echo "Uninstall finished."
else
  echo "Uninstall failed with status $status."
fi
read -r -p "Press Return to close this window..."
exit "$status"
